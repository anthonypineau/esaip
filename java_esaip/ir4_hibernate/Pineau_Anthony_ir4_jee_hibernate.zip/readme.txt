utilisateur base de données (utilisateur par défaut) :
	username:root
	password:network
nom de la base de données : gestionhotel

Pour le test de l'application via la console merci de lancer la classe TestComplet
(Les autres classes sont des classes de test incomplètes)